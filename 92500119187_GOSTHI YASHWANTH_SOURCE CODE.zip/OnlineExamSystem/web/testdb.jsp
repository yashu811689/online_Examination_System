<%@ page import="db.DBConnection" %>
<%-- 
    Document   : testdb
    Created on : Sep 8, 2026, 10:20:28 PM
    Author     : G.YASHWANTH
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%
    java.sql.Connection conn = DBConnection.getConnection();
    if (conn != null) {
        out.println("<h3>Connection Successful!</h3>");
    } else {
        out.println("<h3>Connection Failed!</h3>");
    }
%>
       
    </body>
</html>
