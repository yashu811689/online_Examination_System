<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - Online Exam System</title>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: #0b0f19;
      position: relative;
      overflow: hidden;
      padding: 20px;
    }

    /* Ambient Lighting Glows */
    .glow-bg {
      position: absolute;
      width: 450px;
      height: 450px;
      border-radius: 50%;
      filter: blur(100px);
      opacity: 0.35;
      pointer-events: none;
      z-index: 0;
    }
    .glow-1 {
      top: -100px;
      left: 15%;
      background: #4f46e5;
    }
    .glow-2 {
      bottom: -100px;
      right: 15%;
      background: #06b6d4;
    }

    /* Glass Card */
    .card-container {
      position: relative;
      z-index: 1;
      width: 100%;
      max-width: 420px;
      background: rgba(18, 24, 38, 0.75);
      backdrop-filter: blur(24px);
      -webkit-backdrop-filter: blur(24px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 24px;
      padding: 44px 36px;
      box-shadow: 0 30px 60px rgba(0, 0, 0, 0.45);
    }

    .brand-header {
      text-align: center;
      margin-bottom: 32px;
    }

    .brand-header h2 {
      font-size: 26px;
      font-weight: 700;
      color: #ffffff;
      letter-spacing: -0.5px;
    }

    .brand-header p {
      font-size: 14px;
      color: #94a3b8;
      margin-top: 6px;
    }

    /* Form Fields */
    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      font-size: 13px;
      font-weight: 500;
      color: #cbd5e1;
      margin-bottom: 8px;
    }

    .input-wrapper {
      position: relative;
      display: flex;
      align-items: center;
    }

    .input-wrapper svg {
      position: absolute;
      left: 16px;
      width: 18px;
      height: 18px;
      stroke: #64748b;
      transition: stroke 0.2s ease;
      pointer-events: none;
    }

    .input-wrapper input {
      width: 100%;
      padding: 13px 16px 13px 44px;
      background: rgba(15, 23, 42, 0.6);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 12px;
      color: #f8fafc;
      font-size: 14px;
      font-family: inherit;
      outline: none;
      transition: all 0.25s ease;
    }

    .input-wrapper input::placeholder {
      color: #64748b;
    }

    .input-wrapper input:focus {
      background: rgba(15, 23, 42, 0.85);
      border-color: #6366f1;
      box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.15);
    }

    .input-wrapper input:focus + svg,
    .input-wrapper:focus-within svg {
      stroke: #6366f1;
    }

    /* Submit Button */
    .btn-submit {
      width: 100%;
      padding: 14px;
      margin-top: 8px;
      background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
      color: #ffffff;
      font-family: inherit;
      font-size: 15px;
      font-weight: 600;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.4);
      transition: all 0.25s ease;
    }

    .btn-submit:hover {
      background: linear-gradient(135deg, #4f46e5 0%, #4338ca 100%);
      box-shadow: 0 14px 30px -5px rgba(99, 102, 241, 0.55);
      transform: translateY(-1px);
    }

    .btn-submit:active {
      transform: translateY(0);
    }

    /* Footer */
    .footer-text {
      margin-top: 26px;
      text-align: center;
      font-size: 13px;
      color: #94a3b8;
    }

    .footer-text a {
      color: #818cf8;
      text-decoration: none;
      font-weight: 600;
      transition: color 0.15s ease;
    }

    .footer-text a:hover {
      color: #a5b4fc;
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <!-- Ambient Light Orbs -->
  <div class="glow-bg glow-1"></div>
  <div class="glow-bg glow-2"></div>

  <!-- Main Login Card -->
  <div class="card-container">
    <div class="brand-header">
      <h2>User Login</h2>
      <p>Log in to access your examination portal</p>
    </div>

    <form action="LoginServlet" method="post">
      <div class="form-group">
        <label for="email">Email</label>
        <div class="input-wrapper">
          <svg fill="none" stroke-width="2" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
          </svg>
          <input type="email" id="email" name="email" placeholder="Enter your email" required autocomplete="email">
        </div>
      </div>

      <div class="form-group">
        <label for="password">Password</label>
        <div class="input-wrapper">
          <svg fill="none" stroke-width="2" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
          </svg>
          <input type="password" id="password" name="password" placeholder="Enter your password" required autocomplete="current-password">
        </div>
      </div>

      <button type="submit" class="btn-submit">Login</button>
    </form>

    <div class="footer-text">
      Don't have an account? <a href="Register.html">Register here</a>
    </div>
  </div>

</body>
</html>