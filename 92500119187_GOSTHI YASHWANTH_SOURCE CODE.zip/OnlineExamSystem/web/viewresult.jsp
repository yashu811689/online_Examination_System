<%@ page import="java.sql.*" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Student Exam Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: 30px auto;
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        .stats-container {
            display: flex;
            justify-content: space-around;
            margin-bottom: 25px;
        }
        .stat-card {
            background-color: #007bff;
            color: white;
            padding: 15px 25px;
            border-radius: 6px;
            text-align: center;
            flex: 1;
            margin: 0 10px;
        }
        .stat-card h3 {
            margin: 0;
            font-size: 24px;
        }
        .stat-card p {
            margin: 5px 0 0 0;
            font-size: 14px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #2c3e50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .btn-back {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .btn-back:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Student Performance & Exam Results</h2>

    <%
        // Database credentials
        String dbURL = "jdbc:mysql://localhost:3306/online_exam_db";
        String dbUser = "root";
        String dbPass = "";

        int totalAttempts = 0;
        int sumScores = 0;

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(dbURL, dbUser, dbPass);

            // Query to fetch results along with student name and exam title
            String query = "SELECT r.result_id, u.full_name AS student_name, u.email, e.exam_title AS exam_title, r.score " +
                           "FROM results r " +
                           "LEFT JOIN users u ON r.user_id = u.user_id " +
                           "LEFT JOIN exams e ON r.exam_id = e.exam_id " +
                           "ORDER BY r.result_id DESC";

            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
    %>

    <table>
        <thead>
            <tr>
                <th>Result ID</th>
                <th>Student Name</th>
                <th>Email</th>
                <th>Exam Title</th>
                <th>Score</th>
            </tr>
        </thead>
        <tbody>
            <%
                boolean hasData = false;
                while (rs.next()) {
                    hasData = true;
                    totalAttempts++;
                    int score = rs.getInt("score");
                    sumScores += score;

                    String studentName = rs.getString("student_name") != null ? rs.getString("student_name") : "User #" + rs.getInt("result_id");
                    String email = rs.getString("email") != null ? rs.getString("email") : "-";
                    String examTitle = rs.getString("exam_title") != null ? rs.getString("exam_title") : "General Exam";
            %>
            <tr>
                <td><%= rs.getInt("result_id") %></td>
                <td><%= studentName %></td>
                <td><%= email %></td>
                <td><%= examTitle %></td>
                <td><strong><%= score %></strong></td>
            </tr>
            <%
                }
                if (!hasData) {
            %>
            <tr>
                <td colspan="5">No students have taken the exam yet.</td>
            </tr>
            <%
                }
            %>
        </tbody>
    </table>

    <div class="stats-container" style="margin-top: 30px;">
        <div class="stat-card">
            <h3><%= totalAttempts %></h3>
            <p>Total Attempts</p>
        </div>
        <div class="stat-card" style="background-color: #28a745;">
            <h3><%= totalAttempts > 0 ? String.format("%.2f", (double) sumScores / totalAttempts) : "0" %></h3>
            <p>Average Score</p>
        </div>
    </div>

    <%
        } catch (Exception e) {
            out.println("<p style='color:red;'>Error fetching results: " + e.getMessage() + "</p>");
        } finally {
            if (rs != null) try { rs.close(); } catch (Exception ignored) {}
            if (stmt != null) try { stmt.close(); } catch (Exception ignored) {}
            if (conn != null) try { conn.close(); } catch (Exception ignored) {}
        }
    %>

    <a href="teacher_dashboard.jsp" class="btn-back">Back to Teacher Dashboard</a>
</div>

</body>
</html>