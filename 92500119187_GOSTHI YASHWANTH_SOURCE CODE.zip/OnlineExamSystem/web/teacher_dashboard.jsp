<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Teacher Dashboard - Online Exam System</title>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      min-height: 100vh;
      background-color: #0b0f19;
      color: #f8fafc;
      position: relative;
      overflow-x: hidden;
      padding-bottom: 60px;
    }

    /* Ambient Lighting Background Orbs */
    .glow-bg {
      position: fixed;
      width: 500px;
      height: 500px;
      border-radius: 50%;
      filter: blur(120px);
      opacity: 0.25;
      pointer-events: none;
      z-index: 0;
    }
    .glow-1 {
      top: -100px;
      left: 10%;
      background: #4f46e5;
    }
    .glow-2 {
      bottom: 5%;
      right: 5%;
      background: #06b6d4;
    }

    /* Top Navigation Bar */
    .navbar {
      position: sticky;
      top: 0;
      z-index: 10;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 18px 36px;
      background: rgba(15, 23, 42, 0.75);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }

    .navbar-brand {
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 20px;
      font-weight: 700;
      letter-spacing: -0.5px;
      color: #ffffff;
    }

    .navbar-brand svg {
      width: 24px;
      height: 24px;
      color: #6366f1;
    }

    .logout-btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 9px 18px;
      background: rgba(239, 68, 68, 0.15);
      border: 1px solid rgba(239, 68, 68, 0.35);
      color: #f87171;
      font-size: 13px;
      font-weight: 600;
      border-radius: 10px;
      text-decoration: none;
      transition: all 0.2s ease;
    }

    .logout-btn:hover {
      background: #ef4444;
      color: #ffffff;
      box-shadow: 0 6px 20px rgba(239, 68, 68, 0.35);
      transform: translateY(-1px);
    }

    /* Main Container */
    .container {
      position: relative;
      z-index: 1;
      max-width: 880px;
      margin: 36px auto 0;
      padding: 0 20px;
      display: flex;
      flex-direction: column;
      gap: 28px;
    }

    /* Glass Cards */
    .card {
      background: rgba(18, 24, 38, 0.75);
      backdrop-filter: blur(24px);
      -webkit-backdrop-filter: blur(24px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 20px;
      padding: 32px;
      box-shadow: 0 25px 50px rgba(0, 0, 0, 0.35);
    }

    .card h3 {
      font-size: 20px;
      font-weight: 700;
      color: #ffffff;
      margin-bottom: 8px;
    }

    .card p {
      font-size: 14px;
      color: #94a3b8;
      line-height: 1.6;
      max-width: 600px;
    }

    /* Welcome Banner Action */
    .welcome-card {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      gap: 20px;
    }

    .btn-action {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 12px 22px;
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: #ffffff;
      text-decoration: none;
      font-size: 14px;
      font-weight: 600;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3);
      transition: all 0.25s ease;
    }

    .btn-action:hover {
      background: linear-gradient(135deg, #059669 0%, #047857 100%);
      transform: translateY(-1px);
      box-shadow: 0 12px 24px rgba(16, 185, 129, 0.4);
    }

    /* Form Styles */
    .form-grid {
      display: flex;
      flex-direction: column;
      gap: 20px;
      margin-top: 20px;
    }

    .form-group {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .form-group label {
      font-size: 13px;
      font-weight: 600;
      color: #cbd5e1;
    }

    .form-group input,
    .form-group textarea,
    .form-group select {
      width: 100%;
      padding: 12px 16px;
      background: rgba(15, 23, 42, 0.65);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      color: #f8fafc;
      font-size: 14px;
      font-family: inherit;
      outline: none;
      transition: all 0.2s ease;
    }

    .form-group select option {
      background-color: #0f172a;
      color: #f8fafc;
    }

    .form-group textarea {
      height: 90px;
      resize: vertical;
    }

    .form-group input:focus,
    .form-group textarea:focus,
    .form-group select:focus {
      background: rgba(15, 23, 42, 0.9);
      border-color: #6366f1;
      box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.15);
    }

    /* Options in 2 Columns */
    .options-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }

    @media (max-width: 640px) {
      .options-grid {
        grid-template-columns: 1fr;
      }
    }

    /* Submit Button */
    .btn-submit {
      margin-top: 10px;
      padding: 14px 28px;
      background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
      color: #ffffff;
      font-size: 15px;
      font-weight: 600;
      font-family: inherit;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.4);
      transition: all 0.25s ease;
      align-self: flex-start;
    }

    .btn-submit:hover {
      background: linear-gradient(135deg, #4f46e5 0%, #4338ca 100%);
      transform: translateY(-1px);
      box-shadow: 0 14px 30px -5px rgba(99, 102, 241, 0.55);
    }

    .btn-submit:active {
      transform: translateY(0);
    }
  </style>
</head>
<body>

  <!-- Ambient Glows -->
  <div class="glow-bg glow-1"></div>
  <div class="glow-bg glow-2"></div>

  <!-- Navigation Bar -->
  <nav class="navbar">
    <div class="navbar-brand">
      <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
      </svg>
      <h2>Teacher Dashboard</h2>
    </div>
    <a href="LoginServlet?action=logout" class="logout-btn">
      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
      </svg>
      Logout
    </a>
  </nav>

  <!-- Main Content -->
  <div class="container">
    <!-- Welcome Card -->
    <div class="card welcome-card">
      <div>
        <h3>Welcome to the Teacher Panel!</h3>
        <p>Your login was successful. From this dashboard, you can add questions, create exams, and review overall student participation and scores.</p>
      </div>
      <a href="viewresult.jsp" class="btn-action">📊 View Student Results</a>
    </div>

    <!-- Add Question Card -->
    <div class="card">
      <h3>Add New Question</h3>
      
      <form action="AddQuestionServlet" method="POST" class="form-grid">
        <div class="form-group">
          <label for="exam_id">Exam ID:</label>
          <input type="number" id="exam_id" name="exam_id" value="1" min="1" required>
        </div>

        <div class="form-group">
          <label for="question_text">Question:</label>
          <textarea id="question_text" name="question_text" placeholder="Type the question prompt here..." required></textarea>
        </div>

        <div class="options-grid">
          <div class="form-group">
            <label for="option1">Option A:</label>
            <input type="text" id="option1" name="option1" placeholder="First choice" required>
          </div>

          <div class="form-group">
            <label for="option2">Option B:</label>
            <input type="text" id="option2" name="option2" placeholder="Second choice" required>
          </div>

          <div class="form-group">
            <label for="option3">Option C:</label>
            <input type="text" id="option3" name="option3" placeholder="Third choice" required>
          </div>

          <div class="form-group">
            <label for="option4">Option D:</label>
            <input type="text" id="option4" name="option4" placeholder="Fourth choice" required>
          </div>
        </div>

        <div class="form-group">
          <label for="correct_answer">Correct Answer:</label>
          <select id="correct_answer" name="correct_answer" required>
            <option value="A">Option A</option>
            <option value="B">Option B</option>
            <option value="C">Option C</option>
            <option value="D">Option D</option>
          </select>
        </div>

        <button type="submit" class="btn-submit">Add Question</button>
      </form>
    </div>
  </div>

</body>
</html>