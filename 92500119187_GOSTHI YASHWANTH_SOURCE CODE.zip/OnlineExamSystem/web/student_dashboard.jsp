<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ page import="db.DBConnection" %>

<%
    // Initialize or retrieve user answers map from session
    Map<Integer, String> userAnswers = (Map<Integer, String>) session.getAttribute("userAnswers");
    if (userAnswers == null) {
        userAnswers = new HashMap<Integer, String>();
        session.setAttribute("userAnswers", userAnswers);
    }

    // Save selected answer from the previous question if submitted
    String prevQidStr = request.getParameter("current_question_id");
    String selectedAns = request.getParameter("answer");
    if (prevQidStr != null && selectedAns != null) {
        try {
            int prevQid = Integer.parseInt(prevQidStr);
            userAnswers.put(prevQid, selectedAns);
        } catch (NumberFormatException ignored) {}
    }

    // Determine current index (1-based index)
    int currentIndex = 1;
    String indexParam = request.getParameter("index");
    if (indexParam != null) {
        try {
            currentIndex = Integer.parseInt(indexParam);
        } catch (NumberFormatException e) {
            currentIndex = 1;
        }
    }

    int questionId = 0;
    String questionText = "";
    String optA = "", optB = "", optC = "", optD = "";
    boolean hasNext = false;
    boolean hasPrev = (currentIndex > 1);

    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;

    try {
        conn = DBConnection.getConnection();
        stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        rs = stmt.executeQuery("SELECT * FROM questions ORDER BY question_id ASC");

        if (rs.absolute(currentIndex)) {
            questionId = rs.getInt("question_id");
            questionText = rs.getString("question_text");
            optA = rs.getString("option_a");
            optB = rs.getString("option_b");
            optC = rs.getString("option_c");
            optD = rs.getString("option_d");
        }

        // Check if there is a next question
        if (rs.absolute(currentIndex + 1)) {
            hasNext = true;
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception ignored) {}
        if (stmt != null) try { stmt.close(); } catch (Exception ignored) {}
        if (conn != null) try { conn.close(); } catch (Exception ignored) {}
    }

    String previouslySelected = userAnswers.get(questionId);
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Exam Dashboard</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- MediaPipe Face Mesh & Camera Utils -->
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/face_mesh.js" crossorigin="anonymous"></script>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            min-height: 100vh;
            background-color: #0b0f19;
            color: #f8fafc;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            position: relative;
            overflow-x: hidden;
        }

        /* Ambient Lighting Background Glows */
        .glow-bg {
            position: fixed;
            width: 500px;
            height: 500px;
            border-radius: 50%;
            filter: blur(120px);
            opacity: 0.25;
            pointer-events: none;
            z-index: 0;
        }
        .glow-1 {
            top: -100px;
            left: 10%;
            background: #4f46e5;
        }
        .glow-2 {
            bottom: -50px;
            right: 10%;
            background: #06b6d4;
        }

        /* Card Container */
        .exam-card {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 680px;
            background: rgba(18, 24, 38, 0.75);
            backdrop-filter: blur(24px);
            -webkit-backdrop-filter: blur(24px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 30px 60px rgba(0, 0, 0, 0.45);
        }

        /* Header */
        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }

        .header-top h2 {
            font-size: 22px;
            font-weight: 700;
            color: #ffffff;
            letter-spacing: -0.5px;
        }

        .badge {
            background: rgba(99, 102, 241, 0.15);
            color: #818cf8;
            border: 1px solid rgba(99, 102, 241, 0.3);
            padding: 4px 12px;
            border-radius: 9999px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }

        .subtitle {
            font-size: 14px;
            color: #94a3b8;
            margin-bottom: 24px;
        }

        .divider {
            height: 1px;
            background: rgba(255, 255, 255, 0.08);
            margin-bottom: 28px;
            border: none;
        }

        /* Question Section */
        .question-meta {
            font-size: 13px;
            font-weight: 600;
            color: #6366f1;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            margin-bottom: 8px;
        }

        .question-text {
            font-size: 18px;
            font-weight: 600;
            color: #f1f5f9;
            line-height: 1.5;
            margin-bottom: 28px;
        }

        /* Modern Option Cards */
        .options-list {
            display: flex;
            flex-direction: column;
            gap: 14px;
            margin-bottom: 32px;
        }

        .option-label {
            position: relative;
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 14px 18px;
            background: rgba(15, 23, 42, 0.55);
            border: 1.5px solid rgba(255, 255, 255, 0.08);
            border-radius: 14px;
            cursor: pointer;
            transition: all 0.2s ease;
            user-select: none;
        }

        .option-label:hover {
            background: rgba(30, 41, 59, 0.7);
            border-color: rgba(99, 102, 241, 0.35);
            transform: translateY(-1px);
        }

        /* Custom Radio Button Indicator */
        .option-label input[type="radio"] {
            appearance: none;
            -webkit-appearance: none;
            width: 20px;
            height: 20px;
            border: 2px solid #64748b;
            border-radius: 50%;
            outline: none;
            display: grid;
            place-content: center;
            margin: 0;
            transition: all 0.2s ease;
            flex-shrink: 0;
        }

        .option-label input[type="radio"]::before {
            content: "";
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #6366f1;
            transform: scale(0);
            transition: transform 0.15s ease;
        }

        .option-label input[type="radio"]:checked {
            border-color: #6366f1;
        }

        .option-label input[type="radio"]:checked::before {
            transform: scale(1);
        }

        /* Checked State for Card */
        .option-label:has(input[type="radio"]:checked) {
            background: rgba(99, 102, 241, 0.1);
            border-color: #6366f1;
            box-shadow: 0 0 0 1px #6366f1, 0 8px 20px -4px rgba(99, 102, 241, 0.25);
        }

        .option-text {
            font-size: 15px;
            font-weight: 500;
            color: #e2e8f0;
            line-height: 1.4;
        }

        /* Actions Bar */
        .actions-group {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 14px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 13px 24px;
            font-family: inherit;
            font-size: 14px;
            font-weight: 600;
            border-radius: 12px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.25s ease;
            border: none;
        }

        .btn-back {
            background: rgba(30, 41, 59, 0.7);
            color: #cbd5e1;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .btn-back:hover {
            background: rgba(51, 65, 85, 0.8);
            color: #ffffff;
            transform: translateY(-1px);
        }

        .btn-next {
            background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
            color: #ffffff;
            box-shadow: 0 8px 20px rgba(99, 102, 241, 0.35);
            margin-left: auto;
        }

        .btn-next:hover {
            background: linear-gradient(135deg, #4f46e5 0%, #4338ca 100%);
            box-shadow: 0 12px 24px rgba(99, 102, 241, 0.5);
            transform: translateY(-1px);
        }

        .btn-submit {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: #ffffff;
            box-shadow: 0 8px 20px rgba(16, 185, 129, 0.35);
            margin-left: auto;
        }

        .btn-submit:hover {
            background: linear-gradient(135deg, #059669 0%, #047857 100%);
            box-shadow: 0 12px 24px rgba(16, 185, 129, 0.5);
            transform: translateY(-1px);
        }

        .no-data {
            text-align: center;
            color: #94a3b8;
            padding: 30px 0;
            font-size: 15px;
        }

        /* --- Floating Proctor Camera Box --- */
        .proctor-box {
            position: fixed;
            bottom: 24px;
            right: 24px;
            width: 170px;
            height: 128px;
            border-radius: 16px;
            overflow: hidden;
            background: #000000;
            border: 3px solid rgba(99, 102, 241, 0.6);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.65);
            z-index: 999;
            transition: border-color 0.25s ease, box-shadow 0.25s ease, background-color 0.25s ease;
        }

        .proctor-box video {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transform: scaleX(-1);
            display: block;
        }

        /* Red Background and Border on Violation */
        .proctor-box.violation {
            border-color: #ef4444 !important;
            background-color: #ef4444 !important;
            box-shadow: 0 0 25px 8px rgba(239, 68, 68, 0.8) !important;
            animation: pulse-border 0.8s infinite alternate ease-in-out;
        }

        @keyframes pulse-border {
            from {
                box-shadow: 0 0 15px 4px rgba(239, 68, 68, 0.6);
            }
            to {
                box-shadow: 0 0 35px 12px rgba(239, 68, 68, 0.95);
            }
        }

        .proctor-badge {
            position: absolute;
            top: 8px;
            left: 8px;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(4px);
            padding: 3px 8px;
            border-radius: 6px;
            font-size: 10px;
            font-weight: 700;
            color: #f87171;
            display: flex;
            align-items: center;
            gap: 5px;
            letter-spacing: 0.5px;
            z-index: 2;
        }

        .proctor-dot {
            width: 6px;
            height: 6px;
            background: #ef4444;
            border-radius: 50%;
            animation: pulse-dot 1.2s infinite ease-in-out;
        }

        @keyframes pulse-dot {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.3; transform: scale(0.8); }
        }

        /* Gaze / Boundary Warning Toast */
        #proctor-warning {
            display: none;
            position: fixed;
            top: 24px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(220, 38, 38, 0.95);
            backdrop-filter: blur(12px);
            color: #ffffff;
            padding: 14px 28px;
            border-radius: 14px;
            font-size: 14px;
            font-weight: 600;
            box-shadow: 0 15px 35px rgba(220, 38, 38, 0.4);
            z-index: 1000;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.2s ease;
        }
    </style>
</head>
<body>

    <!-- Ambient Glowing Orbs -->
    <div class="glow-bg glow-1"></div>
    <div class="glow-bg glow-2"></div>

    <!-- Warning Toast Banner -->
    <div id="proctor-warning">⚠️ Please look directly at the screen!</div>

    <!-- Floating Proctor Camera Container -->
    <div class="proctor-box" id="proctor-box">
        <div class="proctor-badge">
            <span class="proctor-dot"></span> PROCTOR ON
        </div>
        <video id="proctor-video" autoplay playsinline muted></video>
    </div>

    <!-- Exam Card -->
    <div class="exam-card">
        <div class="header-top">
            <h2>Online Examination</h2>
            <span class="badge">Live Exam</span>
        </div>
        <p class="subtitle">Please select your answer below and navigate through the test.</p>
        <hr class="divider">

        <% if (questionText != null && !questionText.isEmpty()) { %>
            <form action="<%= hasNext ? "student_dashboard.jsp" : "SubmitExamServlet" %>" method="POST">
                <input type="hidden" name="current_question_id" value="<%= questionId %>">
                <input type="hidden" name="index" value="<%= currentIndex + 1 %>">

                <div class="question-meta">Question <%= currentIndex %></div>
                <div class="question-text"><%= questionText %></div>

                <div class="options-list">
                    <label class="option-label">
                        <input type="radio" name="answer" value="A" <%= "A".equals(previouslySelected) ? "checked" : "" %> required>
                        <span class="option-text"><%= optA %></span>
                    </label>

                    <label class="option-label">
                        <input type="radio" name="answer" value="B" <%= "B".equals(previouslySelected) ? "checked" : "" %>>
                        <span class="option-text"><%= optB %></span>
                    </label>

                    <label class="option-label">
                        <input type="radio" name="answer" value="C" <%= "C".equals(previouslySelected) ? "checked" : "" %>>
                        <span class="option-text"><%= optC %></span>
                    </label>

                    <label class="option-label">
                        <input type="radio" name="answer" value="D" <%= "D".equals(previouslySelected) ? "checked" : "" %>>
                        <span class="option-text"><%= optD %></span>
                    </label>
                </div>

                <div class="actions-group">
                    <% if (hasPrev) { %>
                        <a href="student_dashboard.jsp?index=<%= currentIndex - 1 %>" class="btn btn-back">
                            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
                            </svg>
                            Back
                        </a>
                    <% } else { %>
                        <div></div>
                    <% } %>

                    <% if (hasNext) { %>
                        <button type="submit" class="btn btn-next">
                            Next
                            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
                            </svg>
                        </button>
                    <% } else { %>
                        <button type="submit" class="btn btn-submit">
                            Submit Exam
                            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
                            </svg>
                        </button>
                    <% } %>
                </div>
            </form>
        <% } else { %>
            <p class="no-data">No questions available at the moment.</p>
        <% } %>
    </div>

    <!-- Proctoring Gaze & Boundary-Tracking Logic -->
    <script>
        const videoElement = document.getElementById('proctor-video');
        const proctorBox = document.getElementById('proctor-box');
        const warningBanner = document.getElementById('proctor-warning');
        let warningTimeout = null;

        // Initialize MediaPipe Face Mesh
        const faceMesh = new FaceMesh({
            locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`
        });

        faceMesh.setOptions({
            maxNumFaces: 1,
            refineLandmarks: true,
            minDetectionConfidence: 0.5,
            minTrackingConfidence: 0.5
        });

        faceMesh.onResults(onFaceResults);

        // Connect Camera Stream to MediaPipe pipeline
        const camera = new Camera(videoElement, {
            onFrame: async () => {
                await faceMesh.send({ image: videoElement });
            },
            width: 320,
            height: 240
        });

        camera.start().catch((err) => {
            alert("Camera access is required to take this examination. Please allow webcam permissions.");
            console.error("Camera access error:", err);
        });

        function triggerViolation(message) {
            warningBanner.textContent = "⚠️ " + message;
            warningBanner.style.display = "block";
            if (proctorBox) {
                proctorBox.classList.add('violation');
            }
            clearTimeout(warningTimeout);
            warningTimeout = setTimeout(() => {
                warningBanner.style.display = "none";
            }, 2500);
        }

        function clearViolation() {
            if (warningBanner) {
                warningBanner.style.display = "none";
            }
            if (proctorBox) {
                proctorBox.classList.remove('violation');
            }
        }

        function onFaceResults(results) {
            // 1. Check if face is missing or obscured
            if (!results.multiFaceLandmarks || results.multiFaceLandmarks.length === 0) {
                triggerViolation("Face not detected! Please stay in camera frame.");
                return;
            }

            const landmarks = results.multiFaceLandmarks[0];

            // Key landmarks:
            // 1 = Nose tip, 234 = Left cheek edge, 454 = Right cheek edge, 10 = Forehead top, 152 = Chin bottom
            const nose = landmarks[1];
            const leftCheek = landmarks[234];
            const rightCheek = landmarks[454];
            const topHead = landmarks[10];
            const chin = landmarks[152];

            // Calculate horizontal yaw ratio
            const distLeft = Math.abs(nose.x - leftCheek.x);
            const distRight = Math.abs(rightCheek.x - nose.x);
            const yawRatio = distLeft / (distRight + 0.0001);

            // Condition 1: Looking away horizontally (left or right)
            if (yawRatio < 0.35) {
                triggerViolation("Looking away to the right! Face the screen.");
                return;
            }
            if (yawRatio > 2.85) {
                triggerViolation("Looking away to the left! Face the screen.");
                return;
            }

            // Condition 2: Looking too far up or down past screen edges
            if (nose.y < 0.20 || topHead.y < 0.05) {
                triggerViolation("Looking too far up! Face the screen.");
                return;
            }
            if (nose.y > 0.85 || chin.y > 0.95) {
                triggerViolation("Looking too far down! Face the screen.");
                return;
            }

            // Condition 3: Drifting outside left or right camera boundaries
            if (nose.x < 0.15 || nose.x > 0.85) {
                triggerViolation("Drifting off-screen! Please stay centered.");
                return;
            }

            // Passed all checks
            clearViolation();
        }

        // Tab-switch monitoring
        document.addEventListener("visibilitychange", () => {
            if (document.hidden) {
                triggerViolation("Tab switch detected! Return to the exam immediately.");
                alert("Proctoring Alert: Leaving this tab is strictly forbidden!");
            }
        });
    </script>
</body>
</html>