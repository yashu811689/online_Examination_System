package db;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author G.YASHWANTH
 */
public class DBConnection {
     public static Connection getConnection() {
        Connection con = null;
        try {
            // 1. Load the translator (JDBC Driver)
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // 2. Connect to the XAMPP database
            // (Format: "jdbc:mysql://localhost:3306/your_database_name", "username", "password")
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam_db", "root", "");
            
            System.out.println("Database connected successfully!");
        } catch (Exception e) {
            System.out.println("Uh oh, connection failed: " + e.getMessage());
        }
        return con;
    }

    
}
