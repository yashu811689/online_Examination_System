/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.User;

/**
 *
 * @author G.YASHWANTH
 */
public class Userdao {
    private Connection con;

    // Constructor gets the database connection
    public Userdao(Connection con) {
        this.con = con;
    }

    // Method to insert a new user into the database (Registration)
    public boolean registerUser(User user) {
        boolean isSuccess = false;
        try {
            // SQL query matches your exact table columns (user_id is auto-incremented)
            String query = "INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = this.con.prepareStatement(query);
            
            pstmt.setString(1, user.getFullName());
            pstmt.setString(2, user.getEmail());
            pstmt.setString(3, user.getPassword());
            pstmt.setString(4, user.getRole());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                isSuccess = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return isSuccess;
    }

    // Method to verify user credentials (Login)
    public User loginUser(String email, String password) {
        User user = null;
        try {
            // SQL query to find a matching email and password
            String query = "SELECT * FROM users WHERE email = ? AND password = ?";
            PreparedStatement pstmt = this.con.prepareStatement(query);
            
            pstmt.setString(1, email);
            pstmt.setString(2, password);

            ResultSet rs = pstmt.executeQuery();

            // If a match is found, create a User object with the database data
            if (rs.next()) {
                user = new User(
                    rs.getInt("user_id"),
                    rs.getString("full_name"),
                    rs.getString("email"),
                    rs.getString("password"),
                    rs.getString("role")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user; // Returns the user if found, or null if login fails
    }
   
}
