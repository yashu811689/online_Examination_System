package Controller;

import dao.Userdao;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import db.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.User;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("logout".equals(action)) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate();
            }
            response.sendRedirect("login.jsp");
        } else {
            response.sendRedirect("login.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
            Connection con = DBConnection.getConnection();
            Userdao userdao = new Userdao(con);
            User user = userdao.loginUser(email, password);

            if (user != null) {
                HttpSession session = request.getSession();
                
                // Store both the User object and the user_id integer in the session
                session.setAttribute("user", user);
                session.setAttribute("user_id", user.getUserId());
                
                // Redirecting based on role
                if ("Admin".equals(user.getRole())) {
                    out.println("<script type='text/javascript'>");
                    out.println("alert('Welcome Admin!');");
                    out.println("window.location.href='admin_dashboard.jsp';"); 
                    out.println("</script>");
                } else if ("Teacher".equals(user.getRole())) {
                    out.println("<script type='text/javascript'>");
                    out.println("alert('Welcome Teacher!');");
                    out.println("window.location.href='teacher_dashboard.jsp';"); 
                    out.println("</script>");
                } else {
                    out.println("<script type='text/javascript'>");
                    out.println("alert('Welcome Student!');");
                    out.println("window.location.href='student_dashboard.jsp';"); 
                    out.println("</script>");
                }
            } else {
                out.println("<script type='text/javascript'>");
                out.println("alert('Invalid Email or Password. Please try again.');");
                out.println("window.history.back();");
                out.println("</script>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<script type='text/javascript'>");
            out.println("alert('An error occurred. Please try again later.');");
            out.println("window.history.back();");
            out.println("</script>");
        }
    }
}