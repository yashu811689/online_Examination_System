package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import db.DBConnection;

/**
 *
 * @author G.YASHWANTH
 */
@WebServlet(name = "AddQuestionServlet", urlPatterns = {"/AddQuestionServlet"})
public class AddQuestionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("teacher_dashboard.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String examIdStr = request.getParameter("exam_id");
        String questionText = request.getParameter("question_text");
        String option1 = request.getParameter("option1");
        String option2 = request.getParameter("option2");
        String option3 = request.getParameter("option3");
        String option4 = request.getParameter("option4");
        String correctAnswer = request.getParameter("correct_answer");

        Integer examId = null;
        if (examIdStr != null && !examIdStr.trim().isEmpty()) {
            try {
                examId = Integer.parseInt(examIdStr.trim());
            } catch (NumberFormatException ignored) {}
        }

        try (Connection conn = DBConnection.getConnection()) {

            // Check if exam_id exists in `exams` table; if not, insert NULL to prevent foreign key error
            if (examId != null) {
                String checkSql = "SELECT exam_id FROM exams WHERE exam_id = ?";
                try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                    checkPs.setInt(1, examId);
                    try (ResultSet rs = checkPs.executeQuery()) {
                        if (!rs.next()) {
                            examId = null;
                        }
                    }
                } catch (Exception ignored) {
                    examId = null;
                }
            }

            String sql = "INSERT INTO questions (exam_id, question_text, option_a, option_b, option_c, option_d, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                if (examId != null) {
                    ps.setInt(1, examId);
                } else {
                    ps.setNull(1, java.sql.Types.INTEGER);
                }
                ps.setString(2, questionText);
                ps.setString(3, option1);
                ps.setString(4, option2);
                ps.setString(5, option3);
                ps.setString(6, option4);
                ps.setString(7, correctAnswer != null ? correctAnswer.trim().toUpperCase() : "A");

                int result = ps.executeUpdate();
                if (result > 0) {
                    out.println("<script>alert('Question added successfully!'); window.location.href='teacher_dashboard.jsp?status=success';</script>");
                } else {
                    out.println("<script>alert('Failed to add question.'); window.location.href='teacher_dashboard.jsp?status=failed';</script>");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<script>alert('Database Error: " + e.getMessage().replace("'", "\\'") + "'); window.location.href='teacher_dashboard.jsp?status=error';</script>");
        }
    }

    @Override
    public String getServletInfo() {
        return "Handles adding new exam questions to the database";
    }
}