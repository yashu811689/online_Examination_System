package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import db.DBConnection;
import model.User;

@WebServlet("/SubmitExamServlet")
public class SubmitExamServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();

        // 1. Retrieve user_id from session (User object or direct attribute)
        Integer userId = null;
        User user = (User) session.getAttribute("user");
        if (user != null) {
            userId = user.getUserId();
        } else if (session.getAttribute("user_id") != null) {
            userId = (Integer) session.getAttribute("user_id");
        } else if (session.getAttribute("userId") != null) {
            userId = (Integer) session.getAttribute("userId");
        }

        // 2. Retrieve exam_id from session or request
        Integer examId = (Integer) session.getAttribute("exam_id");
        if (examId == null && session.getAttribute("examId") != null) {
            examId = (Integer) session.getAttribute("examId");
        }

        if (examId == null) {
            String pExamId = request.getParameter("exam_id");
            if (pExamId == null) {
                pExamId = request.getParameter("examId");
            }
            if (pExamId != null && !pExamId.trim().isEmpty()) {
                try {
                    examId = Integer.parseInt(pExamId.trim());
                } catch (NumberFormatException ignored) {}
            }
        }

        // 3. Retrieve the session answers map
        @SuppressWarnings("unchecked")
        Map<Integer, String> userAnswers = (Map<Integer, String>) session.getAttribute("userAnswers");

        // 4. Capture the answer submitted on the very last question (if not already saved)
        String lastQidStr = request.getParameter("current_question_id");
        String lastAns = request.getParameter("answer");
        if (userAnswers != null && lastQidStr != null && lastAns != null) {
            try {
                userAnswers.put(Integer.parseInt(lastQidStr), lastAns);
            } catch (NumberFormatException ignored) {}
        }

        int score = 0;
        int totalQuestions = 0;

        try {
            if (userAnswers != null && !userAnswers.isEmpty()) {
                try (Connection con = DBConnection.getConnection()) {

                    // If examId is still null, attempt to resolve it from the answered questions or the exams table
                    if (examId == null) {
                        Integer firstQId = userAnswers.keySet().iterator().next();
                        String qSql = "SELECT exam_id FROM questions WHERE question_id = ?";
                        try (PreparedStatement qPst = con.prepareStatement(qSql)) {
                            qPst.setInt(1, firstQId);
                            try (ResultSet qRs = qPst.executeQuery()) {
                                if (qRs.next()) {
                                    int resolvedId = qRs.getInt("exam_id");
                                    if (!qRs.wasNull()) {
                                        examId = resolvedId;
                                    }
                                }
                            }
                        } catch (Exception ignored) {}
                    }

                    // Validate examId actually exists in `exams` table to prevent foreign key constraint violations
                    if (examId != null) {
                        String checkExamSql = "SELECT exam_id FROM exams WHERE exam_id = ?";
                        try (PreparedStatement checkPst = con.prepareStatement(checkExamSql)) {
                            checkPst.setInt(1, examId);
                            try (ResultSet checkRs = checkPst.executeQuery()) {
                                if (!checkRs.next()) {
                                    String anyExamSql = "SELECT exam_id FROM exams LIMIT 1";
                                    try (PreparedStatement anyPst = con.prepareStatement(anyExamSql);
                                         ResultSet anyRs = anyPst.executeQuery()) {
                                        if (anyRs.next()) {
                                            examId = anyRs.getInt("exam_id");
                                        } else {
                                            examId = null;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 5. Calculate Score
                    String sql = "SELECT correct_option FROM questions WHERE question_id = ?";
                    try (PreparedStatement pst = con.prepareStatement(sql)) {
                        for (Map.Entry<Integer, String> entry : userAnswers.entrySet()) {
                            totalQuestions++;
                            int qId = entry.getKey();
                            String submitted = entry.getValue();

                            pst.setInt(1, qId);
                            try (ResultSet rs = pst.executeQuery()) {
                                if (rs.next()) {
                                    String correct = rs.getString("correct_option");
                                    if (correct != null && submitted != null &&
                                            correct.trim().equalsIgnoreCase(submitted.trim())) {
                                        score++;
                                    }
                                }
                            }
                        }
                    }

                    // 6. Insert result into database
                    if (userId != null) {
                        String insertResultSql = "INSERT INTO results (user_id, exam_id, score) VALUES (?, ?, ?)";
                        try (PreparedStatement insertPst = con.prepareStatement(insertResultSql)) {
                            insertPst.setInt(1, userId);
                            if (examId != null) {
                                insertPst.setInt(2, examId);
                            } else {
                                insertPst.setNull(2, java.sql.Types.INTEGER);
                            }
                            insertPst.setInt(3, score);
                            insertPst.executeUpdate();
                        }
                    } else {
                        System.err.println("SubmitExamServlet Error: userId is null, result not saved.");
                    }
                }
            }

            // Clear session exam data
            session.removeAttribute("userAnswers");

            // Modern Styled Confirmation Page
            out.println("<!DOCTYPE html>");
            out.println("<html lang='en'>");
            out.println("<head>");
            out.println("  <meta charset='UTF-8'>");
            out.println("  <meta name='viewport' content='width=device-width, initial-scale=1.0'>");
            out.println("  <title>Exam Result - Online Exam System</title>");
            out.println("  <link rel='preconnect' href='https://fonts.googleapis.com'>");
            out.println("  <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>");
            out.println("  <link href='https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap' rel='stylesheet'>");
            out.println("  <style>");
            out.println("    * { box-sizing: border-box; margin: 0; padding: 0; }");
            out.println("    body {");
            out.println("      font-family: 'Plus Jakarta Sans', sans-serif;");
            out.println("      min-height: 100vh;");
            out.println("      display: flex;");
            out.println("      align-items: center;");
            out.println("      justify-content: center;");
            out.println("      background-color: #0b0f19;");
            out.println("      position: relative;");
            out.println("      overflow: hidden;");
            out.println("      padding: 20px;");
            out.println("    }");
            out.println("    .glow-bg {");
            out.println("      position: absolute;");
            out.println("      width: 450px;");
            out.println("      height: 450px;");
            out.println("      border-radius: 50%;");
            out.println("      filter: blur(100px);");
            out.println("      opacity: 0.35;");
            out.println("      pointer-events: none;");
            out.println("    }");
            out.println("    .glow-1 { top: -100px; left: 15%; background: #10b981; }");
            out.println("    .glow-2 { bottom: -100px; right: 15%; background: #6366f1; }");
            out.println("    .result-card {");
            out.println("      position: relative;");
            out.println("      z-index: 1;");
            out.println("      width: 100%;");
            out.println("      max-width: 440px;");
            out.println("      background: rgba(18, 24, 38, 0.8);");
            out.println("      backdrop-filter: blur(24px);");
            out.println("      -webkit-backdrop-filter: blur(24px);");
            out.println("      border: 1px solid rgba(255, 255, 255, 0.08);");
            out.println("      border-radius: 24px;");
            out.println("      padding: 44px 32px;");
            out.println("      text-align: center;");
            out.println("      box-shadow: 0 30px 60px rgba(0, 0, 0, 0.45);");
            out.println("    }");
            out.println("    .icon-wrapper {");
            out.println("      width: 72px;");
            out.println("      height: 72px;");
            out.println("      margin: 0 auto 20px;");
            out.println("      border-radius: 50%;");
            out.println("      background: rgba(16, 185, 129, 0.15);");
            out.println("      border: 1px solid rgba(16, 185, 129, 0.3);");
            out.println("      display: flex;");
            out.println("      align-items: center;");
            out.println("      justify-content: center;");
            out.println("      color: #34d399;");
            out.println("    }");
            out.println("    .result-card h2 {");
            out.println("      font-size: 24px;");
            out.println("      font-weight: 700;");
            out.println("      color: #ffffff;");
            out.println("      letter-spacing: -0.5px;");
            out.println("      margin-bottom: 8px;");
            out.println("    }");
            out.println("    .result-card p {");
            out.println("      font-size: 14px;");
            out.println("      color: #94a3b8;");
            out.println("      margin-bottom: 24px;");
            out.println("    }");
            out.println("    .score-badge {");
            out.println("      display: inline-block;");
            out.println("      padding: 16px 36px;");
            out.println("      background: rgba(16, 185, 129, 0.1);");
            out.println("      border: 1.5px solid rgba(16, 185, 129, 0.35);");
            out.println("      border-radius: 16px;");
            out.println("      margin-bottom: 30px;");
            out.println("    }");
            out.println("    .score-label {");
            out.println("      font-size: 12px;");
            out.println("      font-weight: 600;");
            out.println("      text-transform: uppercase;");
            out.println("      letter-spacing: 1px;");
            out.println("      color: #6ee7b7;");
            out.println("      margin-bottom: 6px;");
            out.println("    }");
            out.println("    .score-val {");
            out.println("      font-size: 32px;");
            out.println("      font-weight: 700;");
            out.println("      color: #ffffff;");
            out.println("    }");
            out.println("    .btn-dashboard {");
            out.println("      display: inline-flex;");
            out.println("      align-items: center;");
            out.println("      justify-content: center;");
            out.println("      gap: 8px;");
            out.println("      width: 100%;");
            out.println("      padding: 14px;");
            out.println("      font-size: 15px;");
            out.println("      font-weight: 600;");
            out.println("      color: #ffffff;");
            out.println("      background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);");
            out.println("      border: none;");
            out.println("      border-radius: 12px;");
            out.println("      text-decoration: none;");
            out.println("      cursor: pointer;");
            out.println("      box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.4);");
            out.println("      transition: all 0.25s ease;");
            out.println("    }");
            out.println("    .btn-dashboard:hover {");
            out.println("      background: linear-gradient(135deg, #4f46e5 0%, #4338ca 100%);");
            out.println("      box-shadow: 0 14px 30px -5px rgba(99, 102, 241, 0.55);");
            out.println("      transform: translateY(-1px);");
            out.println("    }");
            out.println("  </style>");
            out.println("</head>");
            out.println("<body>");
            out.println("  <div class='glow-bg glow-1'></div>");
            out.println("  <div class='glow-bg glow-2'></div>");
            out.println("  <div class='result-card'>");
            out.println("    <div class='icon-wrapper'>");
            out.println("      <svg width='36' height='36' fill='none' stroke='currentColor' stroke-width='2.5' viewBox='0 0 24 24'>");
            out.println("        <path stroke-linecap='round' stroke-linejoin='round' d='M5 13l4 4L19 7'/>");
            out.println("      </svg>");
            out.println("    </div>");
            out.println("    <h2>Exam Submitted Successfully!</h2>");
            out.println("    <p>Your responses have been recorded in the database.</p>");
            out.println("    <div class='score-badge'>");
            out.println("      <div class='score-label'>Final Score</div>");
            out.println("      <div class='score-val'>" + score + " / " + totalQuestions + "</div>");
            out.println("    </div>");
            out.println("    <div>");
            out.println("      <a href='login.jsp' class='btn-dashboard'>");
            out.println("        <svg width='18' height='18' fill='none' stroke='currentColor' stroke-width='2' viewBox='0 0 24 24'>");
            out.println("          <path stroke-linecap='round' stroke-linejoin='round' d='M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'/>");
            out.println("        </svg>");
            out.println("        Back to Login");
            out.println("      </a>");
            out.println("    </div>");
            out.println("  </div>");
            out.println("</body>");
            out.println("</html>");

        } catch (Exception e) {
            e.printStackTrace(out);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}