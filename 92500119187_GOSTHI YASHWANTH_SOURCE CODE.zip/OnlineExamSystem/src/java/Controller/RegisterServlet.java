package Controller;

import db.DBConnection;
import dao.Userdao;
import model.User;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "RegisterServlet", urlPatterns = {"/RegisterServlet"})
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            // 1. Get user input from register.html
            String fullName = request.getParameter("full_name");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String role = request.getParameter("role");

            // 2. Establish database connection and verify it is not null
            Connection con = DBConnection.getConnection();
            if (con == null) {
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Database connection failed. Check DBConnection and MYSQL_URL.');");
                out.println("window.history.back();");
                out.println("</script>");
                return;
            }

            // 3. Create User object and populate fields
            User user = new User();
            user.setFullName(fullName);
            user.setEmail(email);
            user.setPassword(password);
            user.setRole(role);

            // 4. Register the user via Userdao
            Userdao userDao = new Userdao(con);
            boolean isSuccess = userDao.registerUser(user);

            // 5. Provide feedback and redirect to index.html
            if (isSuccess) {
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Registration Successful! Please log in.');");
                out.println("window.location.href = 'index.html';");
                out.println("</script>");
            } else {
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Registration Failed. Email may already exist or table is missing.');");
                out.println("window.history.back();");
                out.println("</script>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            try (PrintWriter out = response.getWriter()) {
                String errorMsg = e.getMessage() != null ? e.getMessage().replace("'", "\\'") : "Unknown error";
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Error: " + errorMsg + "');");
                out.println("window.history.back();");
                out.println("</script>");
            }
        }
    }
}